/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <project.h>

uint8 pwm_flag=0;
CY_ISR(Interrupt_Handle)
{
    UART_UartPutString("ISR.\r\n");
    if(Timer_GetInterruptSource()==Timer_INTR_MASK_CC_MATCH)
    {
        UART_UartPutString("Compare.\r\n");
      
        Timer_ClearInterrupt(Timer_INTR_MASK_CC_MATCH);            
    }
    else if(Timer_GetInterruptSource()==Timer_INTR_MASK_TC)
    {
        UART_UartPutString("Period.\r\n");
        Timer_ClearInterrupt(Timer_INTR_MASK_TC); 
        pwm_flag=0;
    }

    Timer_ClearInterrupt(Timer_INTR_MASK_TC|Timer_INTR_MASK_CC_MATCH); 
    isr_Interrupt_ClearPending();

}
CY_ISR(Wakeup_Interrupt)
{
    Timer_Start();
    pwm_flag=1;
    UART_UartPutString("wakeup.\r\n");
    isr_wakeup_ClearPending();
    HALL_ClearInterrupt();
}
void AppCallBack(uint32 event, void *eventParam)
{ 
}
int main()
{
    CYBLE_BLESS_STATE_T blePower;
    
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    Timer_Start();
    UART_Start();
    isr_Interrupt_StartEx(Interrupt_Handle);
    isr_wakeup_StartEx(Wakeup_Interrupt);
    CyGlobalIntEnable;  /* Uncomment this line to enable global interrupts. */

    CyBle_Start(AppCallBack);             
    for(;;)
    {
        CyBle_EnterLPM(CYBLE_BLESS_DEEPSLEEP);
        /* Place your application code here. */
        UART_UartPutString("Active.\r\n");

        if(pwm_flag==0)
        {
            
            UART_UartPutString("Deepsleep.\r\n");
            while(0u != (UART_SpiUartGetTxBufferSize() + UART_GET_TX_FIFO_SR_VALID)); 
            blePower = CyBle_GetBleSsState();
            if((blePower==CYBLE_BLESS_STATE_DEEPSLEEP)||(blePower == CYBLE_BLESS_STATE_ECO_ON))
                CySysPmDeepSleep();
            else if((blePower != CYBLE_BLESS_STATE_EVENT_CLOSE))
            {           
                /* change HF clock source from IMO to ECO, as IMO is not required and can be stopped to save power */
                CySysClkWriteHfclkDirect(CY_SYS_CLK_HFCLK_ECO); 
                /* stop IMO for reducing power consumption */
                CySysClkImoStop();              
                /* put the CPU to sleep */
                CySysPmSleep();            
                /* starts execution after waking up, start IMO */
                CySysClkImoStart();
                /* change HF clock source back to IMO */
                CySysClkWriteHfclkDirect(CY_SYS_CLK_HFCLK_IMO);
    			
            }
        }
        else 
        {
            UART_UartPutString("Sleep.\r\n");
            while(0u != (UART_SpiUartGetTxBufferSize() + UART_GET_TX_FIFO_SR_VALID));
            CySysPmSleep();
        }
        
    }
}

/* [] END OF FILE */
